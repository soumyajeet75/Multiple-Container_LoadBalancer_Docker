# Multiple-Container-and-Load-Balancer-using-NodeJS-Express-Docker-Composer-and-HAProxy

HAProxy is a free, very fast and reliable solution offering high availability, load balancing, and proxying for TCP and HTTP-based applications. It is particularly suited for very high traffic web sites and powers quite a number of the world's most visited ones. Over the years it has become the de-facto standard opensource load balancer, is now shipped with most mainstream Linux distributions, and is often deployed by default in cloud platforms. 

<img src="https://raw.githubusercontent.com/soumyadip007/Multiple-Container-and-Load-Balancer-using-NodeJS-Express-Docker-Composer-and-HAProxy/master/flow01.png" >

<img src="https://raw.githubusercontent.com/soumyadip007/Multiple-Container-and-Load-Balancer-using-NodeJS-Express-Docker-Composer-and-HAProxy/master/flow2.png" >

<img src="https://raw.githubusercontent.com/soumyadip007/Multiple-Container-and-Load-Balancer-using-NodeJS-Express-Docker-Composer-and-HAProxy/master/flow3.jpg" >
